package com.retro.gta1

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.content.Context
import android.content.SharedPreferences
import kotlin.math.*
import java.util.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        val prefs = getSharedPreferences("gta1save", Context.MODE_PRIVATE)
        setContentView(GameView(this, prefs))
    }
}

private data class Actor(var x: Float, var y: Float, var angle: Float, var color: Int, var alive: Boolean = true)
private data class Car(var x: Float, var y: Float, var angle: Float, var color: Int, var speed: Float = 0f, var occupied: Boolean = false)
private data class Bullet(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float = 0.7f)

class GameView(ctx: Context, private val prefs: SharedPreferences) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = Random(12)
    private val tile = 96f
    private val worldW = 2400f
    private val worldH = 1800f
    private var px = prefs.getFloat("px", 420f)
    private var py = prefs.getFloat("py", 420f)
    private var angle = 0f
    private var health = prefs.getInt("health", 100)
    private var money = prefs.getInt("money", 250)
    private var wanted = prefs.getInt("wanted", 0)
    private var score = prefs.getInt("score", 0)
    private var ammo = 60
    private var mission = 0
    private var missionProgress = 0
    private var missionText = "GO TO THE YELLOW MARKER"
    private var inCar = false
    private var currentCar = -1
    private var paused = false
    private var fireHeld = false
    private var up = false; private var down = false; private var left = false; private var right = false
    private var joyX = 0f; private var joyY = 0f
    private var lastTime = System.nanoTime()
    private var cameraX = 0f; private var cameraY = 0f
    private val cars = ArrayList<Car>()
    private val peds = ArrayList<Actor>()
    private val cops = ArrayList<Actor>()
    private val bullets = ArrayList<Bullet>()
    private val buildings = ArrayList<RectF>()
    private val roads = ArrayList<RectF>()
    private val markerX = 1120f
    private val markerY = 720f
    private var fireCooldown = 0f
    private var toast = "WELCOME TO THE CITY"
    private var toastTime = 3f

    init {
        isFocusable = true
        generateCity()
        generateTraffic()
        generatePeds()
    }

    private fun generateCity() {
        // Procedural block grid: wide avenues, sidewalks and building footprints.
        var y = 0f
        while (y < worldH) {
            var x = 0f
            while (x < worldW) {
                if (x % 480f < 320f && y % 420f < 280f) {
                    val bx = x + 26f + rnd.nextInt(35)
                    val by = y + 24f + rnd.nextInt(30)
                    val bw = 110f + rnd.nextInt(120)
                    val bh = 100f + rnd.nextInt(100)
                    buildings.add(RectF(bx, by, min(worldW - 10, bx + bw), min(worldH - 10, by + bh)))
                }
                x += 480f
            }
            y += 420f
        }
        // Road strips between blocks.
        var x = 0f
        while (x < worldW) { roads.add(RectF(x, 0f, min(x + 150f, worldW), worldH)); x += 480f }
        var y2 = 0f
        while (y2 < worldH) { roads.add(RectF(0f, y2, worldW, min(y2 + 130f, worldH))); y2 += 420f }
    }

    private fun generateTraffic() {
        val colors = intArrayOf(Color.rgb(185,55,45), Color.rgb(45,90,155), Color.rgb(210,190,65), Color.rgb(65,65,65), Color.LTGRAY)
        for (i in 0 until 22) {
            val vertical = i % 2 == 0
            val x = if (vertical) 55f + (i % 6) * 480f else rnd.nextInt(worldW.toInt()).toFloat()
            val y = if (vertical) rnd.nextInt(worldH.toInt()).toFloat() else 65f + (i % 5) * 420f
            cars.add(Car(x, y, if (vertical) Math.PI.toFloat()/2f else 0f, colors[i % colors.size], 35f + rnd.nextInt(35)))
        }
    }

    private fun generatePeds() {
        val colors = intArrayOf(Color.rgb(230,190,150), Color.rgb(40,80,150), Color.rgb(180,65,55), Color.rgb(50,50,50), Color.rgb(220,190,80))
        for (i in 0 until 45) {
            val x = rnd.nextInt(worldW.toInt()).toFloat()
            val y = rnd.nextInt(worldH.toInt()).toFloat()
            peds.add(Actor(x, y, rnd.nextFloat()*6.28f, colors[i % colors.size]))
        }
    }

    private fun clampWorld() {
        px = px.coerceIn(20f, worldW-20f); py = py.coerceIn(20f, worldH-20f)
    }

    private fun update(dt0: Float) {
        if (paused) return
        val dt = dt0.coerceIn(0f, 0.04f)
        fireCooldown -= dt
        toastTime -= dt
        if (inCar && currentCar in cars.indices) {
            val c = cars[currentCar]
            if (up) c.speed = (c.speed + 100f*dt).coerceAtMost(230f)
            if (down) c.speed = (c.speed - 140f*dt).coerceAtLeast(-80f)
            c.speed *= (1f - 0.8f*dt)
            if (left) c.angle -= 2.3f*dt*(0.4f + abs(c.speed)/150f)
            if (right) c.angle += 2.3f*dt*(0.4f + abs(c.speed)/150f)
            c.x += cos(c.angle)*c.speed*dt; c.y += sin(c.angle)*c.speed*dt
            c.x = c.x.coerceIn(15f, worldW-15f); c.y = c.y.coerceIn(15f, worldH-15f)
            px = c.x; py = c.y; angle = c.angle
        } else {
            val dx = (if (right) 1f else 0f) - (if (left) 1f else 0f)
            val dy = (if (down) 1f else 0f) - (if (up) 1f else 0f)
            val mag = sqrt(dx*dx+dy*dy)
            if (mag > 0f) {
                angle = atan2(dy, dx)
                px += dx/mag*155f*dt; py += dy/mag*155f*dt
            }
            clampWorld()
        }

        // Traffic movement and pedestrian wandering.
        for (c in cars) if (!c.occupied) {
            if (c.speed == 0f) c.speed = 45f
            c.x += cos(c.angle)*c.speed*dt; c.y += sin(c.angle)*c.speed*dt
            if (c.x < 0f || c.x > worldW || c.y < 0f || c.y > worldH) {
                c.x = (c.x+worldW)%worldW; c.y = (c.y+worldH)%worldH
            }
        }
        for (a in peds) if (a.alive) {
            a.x += cos(a.angle)*18f*dt; a.y += sin(a.angle)*18f*dt
            if (rnd.nextFloat() < 0.006f) a.angle += (rnd.nextFloat()-0.5f)*2f
            if (a.x < 10f || a.x > worldW-10f || a.y < 10f || a.y > worldH-10f) a.angle += 2.5f
        }
        for (a in cops) if (a.alive) {
            val targetX = px; val targetY = py
            val a2 = atan2(targetY-a.y, targetX-a.x)
            a.angle = a2; a.x += cos(a2)*70f*dt; a.y += sin(a2)*70f*dt
            if (hypot((a.x-px).toDouble(), (a.y-py).toDouble()) < 24) {
                health = (health - 7).coerceAtLeast(0)
                if (health == 0) respawn()
            }
        }
        val it = bullets.iterator()
        while (it.hasNext()) {
            val b = it.next()
            b.x += b.vx*dt; b.y += b.vy*dt; b.life -= dt
            var hit = false
            for (a in peds) if (a.alive && hypot((a.x-b.x).toDouble(), (a.y-b.y).toDouble()) < 17) {
                a.alive = false; money += 5; score += 100; wanted = (wanted+1).coerceAtMost(5); hit = true; break
            }
            if (b.life <= 0f || hit) it.remove()
        }
        if (fireHeld && fireCooldown <= 0f && ammo > 0 && !inCar) {
            bullets.add(Bullet(px+cos(angle)*18, py+sin(angle)*18, cos(angle)*420, sin(angle)*420))
            ammo--; fireCooldown = 0.22f
        }
        if (wanted > 0 && cops.size < wanted*2) {
            cops.add(Actor((px+500).coerceIn(10f,worldW-10f), (py+350).coerceIn(10f,worldH-10f), 0f, Color.rgb(35,75,190)))
        }
        if (wanted == 0) cops.clear()
        if (hypot((px-markerX).toDouble(), (py-markerY).toDouble()) < 55) {
            missionProgress++
            if (missionProgress > 2) {
                mission++; missionProgress = 0; money += 500; score += 1000
                missionText = when (mission % 4) {
                    0 -> "GO TO THE YELLOW MARKER"
                    1 -> "DELIVER THE CAR TO THE GARAGE"
                    2 -> "COLLECT THE PACKAGE"
                    else -> "ESCAPE THE POLICE"
                }
                toast = "MISSION COMPLETE  +$500"; toastTime = 3f
            }
        }
        cameraX = (px - width/2f).coerceIn(0f, max(0f,worldW-width))
        cameraY = (py - height/2f).coerceIn(0f, max(0f,worldH-height))
    }

    private fun respawn() {
        health = 100; wanted = 0; cops.clear(); inCar = false; currentCar = -1
        px = 420f; py = 420f; money = (money-250).coerceAtLeast(0)
        toast = "WASTED - HOSPITAL FEE $250"; toastTime = 4f
    }

    private fun save() {
        prefs.edit().putFloat("px",px).putFloat("py",py).putInt("health",health)
            .putInt("money",money).putInt("wanted",wanted).putInt("score",score).apply()
        toast = "GAME SAVED"; toastTime = 2f
    }

    private fun enterExitCar() {
        if (inCar) {
            val c = cars[currentCar]
            px = c.x + 35f; py = c.y + 35f
            c.occupied = false; inCar = false; currentCar = -1
            toast = "EXIT VEHICLE"; toastTime = 1.5f
        } else {
            var best = -1; var dist = 65f
            for (i in cars.indices) {
                val d = hypot((cars[i].x-px).toDouble(), (cars[i].y-py).toDouble()).toFloat()
                if (d < dist) { dist = d; best = i }
            }
            if (best >= 0) {
                currentCar = best; inCar = true; cars[best].occupied = true
                toast = "VEHICLE ENTERED"; toastTime = 1.5f
            } else { toast = "NO CAR NEARBY"; toastTime = 1.5f }
        }
    }

    private fun drawText(c: Canvas, text: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean = true) {
        p.color = color; p.textSize = size; p.typeface = if (bold) android.graphics.Typeface.create("sans-serif-condensed", android.graphics.Typeface.BOLD) else android.graphics.Typeface.DEFAULT
        c.drawText(text, x, y, p)
    }
    private fun rect(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        p.color = color; c.drawRect(l,t,r,b,p)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = ((now-lastTime)/1e9).toFloat(); lastTime = now
        update(dt)
        val save = canvas.save()
        canvas.translate(-cameraX,-cameraY)
        rect(canvas,0f,0f,worldW,worldH,Color.rgb(62,105,65))
        // roads and lane markings
        for (r in roads) {
            p.color = Color.rgb(62,62,62); canvas.drawRect(r,p)
            p.color = Color.rgb(95,95,88); p.style = Paint.Style.STROKE; p.strokeWidth = 2f; canvas.drawRect(r,p); p.style = Paint.Style.FILL
        }
        var rx=75f
        while(rx<worldW){ p.color=Color.rgb(205,190,125); p.strokeWidth=3f; var yy=0f; while(yy<worldH){ canvas.drawLine(rx,yy,rx+18,yy,p); yy+=52f }; rx+=480f }
        var ry=65f
        while(ry<worldH){ p.color=Color.rgb(205,190,125); p.strokeWidth=3f; var xx=0f; while(xx<worldW){ canvas.drawLine(xx,ry,xx+18,ry,p); xx+=52f }; ry+=420f }
        // building shadows and roofs
        for (b in buildings) {
            p.color=Color.argb(70,0,0,0); canvas.drawRoundRect(RectF(b.left+9,b.top+10,b.right+9,b.bottom+10),5f,5f,p)
            p.color=Color.rgb(130,119,102); canvas.drawRoundRect(b,4f,4f,p)
            p.color=Color.rgb(165,153,132); canvas.drawRect(b.left+8,b.top+8,b.right-8,b.top+17,p)
            p.color=Color.rgb(85,83,78); canvas.drawRect(b.left+15,b.top+25,b.right-15,b.bottom-12,p)
            p.color=Color.rgb(190,175,145); canvas.drawRect(b.left+22,b.top+32,b.left+31,b.top+43,p)
        }
        // mission marker
        p.color=Color.argb(75,255,220,0); canvas.drawCircle(markerX,markerY,48f,p)
        p.color=Color.YELLOW; p.style=Paint.Style.STROKE; p.strokeWidth=5f; canvas.drawCircle(markerX,markerY,32f,p); p.style=Paint.Style.FILL
        // peds
        for (a in peds) if (a.alive) {
            p.color=Color.argb(90,0,0,0); canvas.drawCircle(a.x+4,a.y+5,9f,p)
            p.color=a.color; canvas.drawCircle(a.x,a.y,8f,p)
            p.color=Color.rgb(30,25,20); canvas.drawCircle(a.x+cos(a.angle)*4,a.y+sin(a.angle)*4,2.5f,p)
        }
        // cars
        for (c in cars) {
            val sv=canvas.save(); canvas.rotate(c.angle*180f/Math.PI.toFloat(),c.x,c.y)
            p.color=Color.rgb(20,20,20); canvas.drawRoundRect(RectF(c.x-24,c.y-13,c.x+24,c.y+13),5f,5f,p)
            p.color=c.color; canvas.drawRoundRect(RectF(c.x-21,c.y-11,c.x+21,c.y+11),4f,4f,p)
            p.color=Color.rgb(80,115,130); canvas.drawRect(c.x-7,c.y-9,c.x+9,c.y+9,p)
            p.color=Color.YELLOW; canvas.drawRect(c.x+18,c.y-8,c.x+21,c.y-4,p)
            canvas.restoreToCount(sv)
        }
        // cops
        for (a in cops) if (a.alive) {
            p.color=Color.rgb(20,40,100); canvas.drawCircle(a.x,a.y,11f,p)
            p.color=Color.WHITE; canvas.drawRect(a.x-4,a.y-8,a.x+4,a.y-3,p)
        }
        // bullets
        p.color=Color.YELLOW
        for (b in bullets) canvas.drawCircle(b.x,b.y,4f,p)
        // player
        if (!inCar) {
            p.color=Color.argb(100,0,0,0); canvas.drawCircle(px+4,py+5,12f,p)
            p.color=Color.rgb(235,185,130); canvas.drawCircle(px,py,10f,p)
            p.color=Color.rgb(35,45,65); canvas.drawCircle(px,py+4,7f,p)
            p.color=Color.BLACK; canvas.drawCircle(px+cos(angle)*7,py+sin(angle)*7,2.5f,p)
        }
        canvas.restoreToCount(save)
        drawHud(canvas)
        drawControls(canvas)
        if (paused) {
            rect(canvas,0f,0f,width.toFloat(),height.toFloat(),Color.argb(190,0,0,0))
            drawText(canvas,"PAUSED",width/2f-90,height/2f,42f,Color.WHITE)
            drawText(canvas,"TAP RESUME",width/2f-85,height/2f+42,20f,Color.YELLOW)
        }
        postInvalidateDelayed(16)
    }

    private fun drawHud(c: Canvas) {
        rect(c,0f,0f,width.toFloat(),56f,Color.argb(220,12,18,22))
        drawText(c,"GTA",14f,34f,27f,Color.WHITE)
        drawText(c,"$money",100f,32f,21f,Color.rgb(90,220,110))
        drawText(c,"SCORE $score",210f,30f,16f,Color.WHITE)
        drawText(c,"AMMO $ammo",330f,30f,16f,Color.WHITE)
        drawText(c,"HEALTH",width-260f,20f,13f,Color.WHITE)
        rect(c,width-260f,27f,width-130f,40f,Color.DKGRAY)
        rect(c,width-260f,27f,width-260f+130f*health/100f,40f,Color.rgb(210,55,50))
        drawText(c,"★".repeat(wanted),width-115f,34f,19f,Color.YELLOW)
        rect(c,12f,64f, min(width-12f, 390f), 105f,Color.argb(190,10,15,20))
        drawText(c,"MISSION ${mission+1}: $missionText",22f,91f,14f,Color.YELLOW)
        if (toastTime>0) {
            val tw=p.measureText(toast)
            rect(c,width/2f-tw/2f-18, height*0.18f-24,width/2f+tw/2f+18,height*0.18f+8,Color.argb(210,0,0,0))
            drawText(c,toast,width/2f-tw/2f,height*0.18f,18f,Color.WHITE)
        }
        // minimap
        val mx=width-115f; val my=height-112f
        p.color=Color.argb(220,15,20,23); c.drawCircle(mx,my,82f,p)
        p.color=Color.rgb(100,105,100); p.strokeWidth=7f
        for (i in -2..2) { c.drawLine(mx+i*27,my-65,mx+i*27,my+65,p); c.drawLine(mx-65,my+i*27,mx+65,my+i*27,p) }
        p.color=Color.YELLOW; c.drawCircle(mx+(markerX-px)*0.07f,my+(markerY-py)*0.07f,4f,p)
        p.color=Color.CYAN; c.drawCircle(mx,my,6f,p)
    }

    private fun drawButton(c: Canvas, label: String, x: Float, y: Float, radius: Float, active: Boolean = false) {
        p.color=if(active) Color.argb(210,220,170,40) else Color.argb(170,10,15,20)
        c.drawCircle(x,y,radius,p); p.color=Color.WHITE; p.style=Paint.Style.STROKE; p.strokeWidth=2f; c.drawCircle(x,y,radius,p); p.style=Paint.Style.FILL
        p.textSize=15f; p.typeface=android.graphics.Typeface.DEFAULT_BOLD
        val w=p.measureText(label); p.color=Color.WHITE; c.drawText(label,x-w/2,y+5,p)
    }

    private fun drawControls(c: Canvas) {
        val baseX=92f; val baseY=height-105f
        p.color=Color.argb(85,0,0,0); c.drawCircle(baseX,baseY,76f,p)
        p.color=Color.argb(180,220,220,220); c.drawCircle(baseX+joyX*38,baseY+joyY*38,25f,p)
        drawButton(c,"FIRE",width-90f,height-95f,48f,fireHeld)
        drawButton(c,if(inCar) "EXIT" else "CAR",width-205f,height-95f,42f)
        drawButton(c,"SAVE",width-90f,90f,32f)
        drawButton(c,"PAUSE",width-205f,90f,32f)
        drawButton(c,"JOB",width-320f,height-95f,38f)
    }

    private fun touchButton(x: Float,y: Float,cx: Float,cy: Float,r: Float)=hypot((x-cx).toDouble(),(y-cy).toDouble())<=r
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val x=e.x; val y=e.y
        when(e.action and MotionEvent.ACTION_MASK) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                if (touchButton(x,y,width-90f,height-95f,55f)) fireHeld=true
                else if (touchButton(x,y,width-205f,height-95f,48f)) enterExitCar()
                else if (touchButton(x,y,width-90f,90f,38f)) save()
                else if (touchButton(x,y,width-205f,90f,38f)) paused=!paused
                else if (touchButton(x,y,width-320f,height-95f,44f)) { missionText="FOLLOW THE YELLOW MARKER"; toast="MISSION STARTED"; toastTime=2f }
                else if (x<210f && y>height-210f) {
                    val dx=x-92f; val dy=y-(height-105f); val m=max(1f,hypot(dx.toDouble(),dy.toDouble()).toFloat())
                    joyX=(dx/m).coerceIn(-1f,1f); joyY=(dy/m).coerceIn(-1f,1f)
                    left=joyX < -0.25f; right=joyX > 0.25f; up=joyY < -0.25f; down=joyY > 0.25f
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (x<210f && y>height-210f) {
                    val dx=x-92f; val dy=y-(height-105f); val m=max(1f,hypot(dx.toDouble(),dy.toDouble()).toFloat())
                    joyX=(dx/m).coerceIn(-1f,1f); joyY=(dy/m).coerceIn(-1f,1f)
                    left=joyX < -0.25f; right=joyX > 0.25f; up=joyY < -0.25f; down=joyY > 0.25f
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                fireHeld=false; joyX=0f; joyY=0f; up=false;down=false;left=false;right=false
            }
        }
        invalidate()
        return true
    }
}
