package com.example.gta1kotlin

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.MotionEvent
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Typeface
import android.content.Context
import android.view.Window
import android.view.WindowManager
import kotlin.math.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(GameView(this))
    }
}

private data class Car(var x: Float, var y: Float, var color: Int, var angle: Float = 0f)
private data class Shot(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float = 0.65f)

class GameView(context: Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val density = resources.displayMetrics.density
    private var sx = 0f
    private var sy = 0f
    private var scale = 1f
    private var playerX = 180f
    private var playerY = 180f
    private var playerAngle = 0f
    private var inCar = false
    private var currentCar = -1
    private var cash = 0
    private var wanted = 0
    private var missionIndex = 0
    private var shootCooldown = 0f
    private var lastTime = System.nanoTime()
    private var joyX = 0f
    private var joyY = 0f
    private var joyActive = false
    private var firePressed = false
    private var enterPressed = false
    private var missionPressed = false
    private val shots = ArrayList<Shot>()
    private val cars = arrayListOf(
        Car(270f, 56f, Color.rgb(205, 65, 55)),
        Car(430f, 175f, Color.rgb(224, 178, 66), 1.57f),
        Car(750f, 170f, Color.rgb(68, 125, 180), 1.57f),
        Car(1070f, 280f, Color.rgb(210, 210, 200), 1.57f),
        Car(170f, 490f, Color.rgb(66, 160, 120))
    )
    private val missionTargets = arrayOf(floatArrayOf(172f, 172f), floatArrayOf(1370f, 1370f))

    private fun col(hex: String): Int = Color.parseColor(hex)

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = System.nanoTime()
        val dt = min(0.05f, (now - lastTime) / 1_000_000_000f)
        lastTime = now
        updateGame(dt)

        val vw = width.toFloat()
        val vh = height.toFloat()
        val worldW = 1600f
        val worldH = 1600f
        scale = min(vw / 900f, vh / 520f)
        val viewWorldW = vw / scale
        val viewWorldH = vh / scale
        val focusX = if (inCar && currentCar >= 0) cars[currentCar].x else playerX
        val focusY = if (inCar && currentCar >= 0) cars[currentCar].y else playerY
        sx = (vw / scale / 2f - focusX).coerceIn(vw / scale - worldW, 0f)
        sy = (vh / scale / 2f - focusY).coerceIn(vh / scale - worldH, 0f)

        canvas.save()
        canvas.scale(scale, scale)
        canvas.translate(sx, sy)
        drawWorld(canvas)
        drawActors(canvas)
        canvas.restore()
        drawHud(canvas)
        drawTouchControls(canvas)
        postInvalidateDelayed(16)
    }

    private fun updateGame(dt: Float) {
        if (joyActive) {
            val dx = joyX
            val dy = joyY
            if (inCar && currentCar >= 0) {
                val c = cars[currentCar]
                if (abs(dx) + abs(dy) > 0.15f) {
                    c.angle = atan2(dy, dx)
                    c.x += cos(c.angle) * 250f * dt
                    c.y += sin(c.angle) * 250f * dt
                }
            } else {
                if (abs(dx) + abs(dy) > 0.15f) {
                    playerAngle = atan2(dy, dx)
                    playerX += dx * 180f * dt
                    playerY += dy * 180f * dt
                }
            }
        }
        playerX = playerX.coerceIn(20f, 1580f)
        playerY = playerY.coerceIn(20f, 1580f)
        for (c in cars) {
            c.x = c.x.coerceIn(20f, 1580f)
            c.y = c.y.coerceIn(20f, 1580f)
        }
        shootCooldown -= dt
        if (firePressed && !inCar && shootCooldown <= 0f) {
            shots.add(Shot(playerX, playerY, cos(playerAngle) * 520f, sin(playerAngle) * 520f))
            shootCooldown = 0.24f
            wanted = min(5, wanted + 1)
        }
        val iterator = shots.iterator()
        while (iterator.hasNext()) {
            val s = iterator.next()
            s.x += s.vx * dt
            s.y += s.vy * dt
            s.life -= dt
            if (s.life <= 0f) iterator.remove()
        }
        if (missionPressed) {
            val target = missionTargets[missionIndex % missionTargets.size]
            val px = if (inCar && currentCar >= 0) cars[currentCar].x else playerX
            val py = if (inCar && currentCar >= 0) cars[currentCar].y else playerY
            if (hypot(px - target[0], py - target[1]) < 75f) {
                cash += 500
                wanted = max(0, wanted - 1)
                missionIndex++
            }
            missionPressed = false
        }
    }

    private fun drawWorld(c: Canvas) {
        p.color = col("#496D45")
        c.drawRect(0f, 0f, 1600f, 1600f, p)
        for (i in 0..5) {
            val pos = i * 320f
            p.color = col("#34383B")
            c.drawRect(pos, 0f, pos + 112f, 1600f, p)
            c.drawRect(0f, pos, 1600f, pos + 112f, p)
            p.color = col("#88877D")
            c.drawRect(pos + 105f, 0f, pos + 112f, 1600f, p)
            c.drawRect(0f, pos + 105f, 1600f, pos + 112f, p)
            p.color = col("#E8D99A")
            for (k in 0..32) {
                val d = k * 48f
                c.drawRect(pos + 53f, d, pos + 57f, d + 23f, p)
                c.drawRect(d, pos + 53f, d + 23f, pos + 57f, p)
            }
        }
        for (y in 0..4) for (x in 0..4) {
            val l = x * 320f + 124f
            val t = y * 320f + 124f
            p.color = col("#9B7960")
            c.drawRect(l, t, l + 184f, t + 184f, p)
            p.color = col("#B58C6A")
            c.drawRect(l + 12f, t + 12f, l + 172f, t + 172f, p)
            p.color = col("#827D70")
            c.drawRect(l + 35f, t + 32f, l + 87f, t + 70f, p)
            c.drawRect(l + 105f, t + 120f, l + 150f, t + 150f, p)
        }
        val target = missionTargets[missionIndex % missionTargets.size]
        p.color = Color.argb(75, 255, 220, 70)
        c.drawCircle(target[0], target[1], 25f, p)
        p.color = col("#FFE36B")
        p.style = Paint.Style.STROKE
        p.strokeWidth = 4f
        c.drawCircle(target[0], target[1], 25f, p)
        p.style = Paint.Style.FILL
    }

    private fun drawActors(c: Canvas) {
        for (car in cars) {
            c.save()
            c.rotate(Math.toDegrees(car.angle.toDouble()).toFloat(), car.x, car.y)
            p.color = col("#1D2227")
            c.drawRoundRect(RectF(car.x - 21, car.y - 13, car.x + 21, car.y + 13), 4f, 4f, p)
            p.color = car.color
            c.drawRoundRect(RectF(car.x - 18, car.y - 10, car.x + 18, car.y + 10), 3f, 3f, p)
            p.color = col("#A8C7D4")
            c.drawRect(car.x - 5, car.y - 8, car.x + 8, car.y + 8, p)
            c.restore()
        }
        if (!inCar) {
            p.color = Color.argb(80, 0, 0, 0)
            c.drawCircle(playerX + 3, playerY + 5, 13f, p)
            p.color = col("#E7BD91")
            c.drawCircle(playerX, playerY, 10f, p)
            p.color = col("#334B70")
            c.drawCircle(playerX, playerY + 3, 7f, p)
            p.color = col("#46352B")
            c.drawCircle(playerX, playerY - 7, 5f, p)
        }
        p.color = col("#FFE17A")
        for (s in shots) c.drawCircle(s.x, s.y, 3.5f, p)
    }

    private fun drawHud(c: Canvas) {
        p.color = Color.argb(185, 10, 14, 18)
        c.drawRoundRect(RectF(12f, 12f, width - 12f, 58f), 8f, 8f, p)
        p.color = Color.WHITE
        p.textSize = 18f * density
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        c.drawText("GTA 1 KOTLIN     CASH: \$${cash}     WANTED: ${"★".repeat(wanted)}${"☆".repeat(5-wanted)}", 24f, 39f * density, p)
        p.textSize = 12f * density
        p.typeface = Typeface.DEFAULT
        c.drawText(if (inCar) "DRIVING" else "ON FOOT", width - 115f * density, 39f * density, p)
    }

    private fun drawTouchControls(c: Canvas) {
        val d = density
        val baseX = 88f * d
        val baseY = height - 88f * d
        p.color = Color.argb(90, 255, 255, 255)
        c.drawCircle(baseX, baseY, 55f * d, p)
        p.color = Color.argb(170, 230, 230, 230)
        c.drawCircle(baseX + joyX * 35f * d, baseY + joyY * 35f * d, 22f * d, p)
        drawButton(c, width - 75f*d, height - 80f*d, "FIRE")
        drawButton(c, width - 75f*d, height - 180f*d, if (inCar) "EXIT" else "CAR")
        drawButton(c, width - 185f*d, height - 80f*d, "JOB")
    }

    private fun drawButton(c: Canvas, x: Float, y: Float, label: String) {
        p.color = Color.argb(145, 20, 28, 38)
        c.drawCircle(x, y, 34f * density, p)
        p.color = Color.WHITE
        p.textSize = 12f * density
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(label, x - p.measureText(label) / 2f, y + 4f*density, p)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val d = density
        val fireX = width - 75f*d
        val fireY = height - 80f*d
        val carX = width - 75f*d
        val carY = height - 180f*d
        val jobX = width - 185f*d
        val jobY = height - 80f*d
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_MOVE -> {
                joyActive = false
                firePressed = false
                for (i in 0 until event.pointerCount) {
                    val x = event.getX(i)
                    val y = event.getY(i)
                    if (x < width * 0.45f && y > height * 0.48f) {
                        val cx = 88f*d
                        val cy = height - 88f*d
                        joyX = ((x - cx) / (55f*d)).coerceIn(-1f, 1f)
                        joyY = ((y - cy) / (55f*d)).coerceIn(-1f, 1f)
                        joyActive = true
                    }
                    if (hypot(x-fireX, y-fireY) < 45f*d) firePressed = true
                    if (hypot(x-carX, y-carY) < 45f*d) enterPressed = true
                    if (hypot(x-jobX, y-jobY) < 45f*d) missionPressed = true
                }
                if (enterPressed) {
                    toggleCar()
                    enterPressed = false
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                joyActive = false
                joyX = 0f
                joyY = 0f
                firePressed = false
                enterPressed = false
                return true
            }
        }
        return true
    }

    private fun toggleCar() {
        if (inCar && currentCar >= 0) {
            playerX = cars[currentCar].x + 35f
            playerY = cars[currentCar].y
            inCar = false
            currentCar = -1
            return
        }
        var nearest = -1
        var best = 58f
        for (i in cars.indices) {
            val d = hypot(cars[i].x - playerX, cars[i].y - playerY)
            if (d < best) { best = d; nearest = i }
        }
        if (nearest >= 0) {
            currentCar = nearest
            inCar = true
        }
    }
}
